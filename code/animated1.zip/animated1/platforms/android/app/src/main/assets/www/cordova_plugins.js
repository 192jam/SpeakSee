cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "cordova-plugin-statusbar.statusbar",
    "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
    "pluginId": "cordova-plugin-statusbar",
    "clobbers": [
      "window.StatusBar"
    ]
  },
  {
    "id": "cordova-plugin-device.device",
    "file": "plugins/cordova-plugin-device/www/device.js",
    "pluginId": "cordova-plugin-device",
    "clobbers": [
      "device"
    ]
  },
  {
    "id": "cordova-plugin-splashscreen.SplashScreen",
    "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
    "pluginId": "cordova-plugin-splashscreen",
    "clobbers": [
      "navigator.splashscreen"
    ]
  },
  {
    "id": "cordova-plugin-ionic-webview.IonicWebView",
    "file": "plugins/cordova-plugin-ionic-webview/src/www/util.js",
    "pluginId": "cordova-plugin-ionic-webview",
    "clobbers": [
      "Ionic.WebView"
    ]
  },
  {
    "id": "cordova-plugin-ionic-keyboard.keyboard",
    "file": "plugins/cordova-plugin-ionic-keyboard/www/android/keyboard.js",
    "pluginId": "cordova-plugin-ionic-keyboard",
    "clobbers": [
      "window.Keyboard"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechRecognition",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechRecognition.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechRecognition"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechRecognitionError",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechRecognitionError.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechRecognitionError"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechRecognitionAlternative",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechRecognitionAlternative.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechRecognitionAlternative"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechRecognitionResult",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechRecognitionResult.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechRecognitionResult"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechRecognitionResultList",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechRecognitionResultList.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechRecognitionResultList"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechRecognitionEvent",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechRecognitionEvent.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechRecognitionEvent"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechGrammar",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechGrammar.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechGrammar"
    ]
  },
  {
    "id": "phonegap-plugin-speech-recognition.SpeechGrammarList",
    "file": "plugins/phonegap-plugin-speech-recognition/www/SpeechGrammarList.js",
    "pluginId": "phonegap-plugin-speech-recognition",
    "clobbers": [
      "SpeechGrammarList"
    ]
  },
  {
    "id": "cordova-plugin-speechrecognition.SpeechRecognition",
    "file": "plugins/cordova-plugin-speechrecognition/www/speechRecognition.js",
    "pluginId": "cordova-plugin-speechrecognition",
    "merges": [
      "window.plugins.speechRecognition"
    ]
  },
  {
    "id": "cordova-plugin-x-toast.Toast",
    "file": "plugins/cordova-plugin-x-toast/www/Toast.js",
    "pluginId": "cordova-plugin-x-toast",
    "clobbers": [
      "window.plugins.toast"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-plugin-statusbar": "2.4.2",
  "cordova-plugin-device": "2.0.2",
  "cordova-plugin-splashscreen": "5.0.2",
  "cordova-plugin-ionic-webview": "3.1.2",
  "cordova-plugin-ionic-keyboard": "2.1.3",
  "phonegap-plugin-speech-recognition": "0.3.0",
  "cordova-plugin-speechrecognition": "1.1.2",
  "cordova-plugin-x-toast": "2.7.2"
};
// BOTTOM OF METADATA
});