cordova.define("phonegap-plugin-speech-recognition.SpeechGrammar", function(require, exports, module) {
var SpeechGrammar = function() {
    this.src;
    this.weight;
};

module.exports = SpeechGrammar;

});
