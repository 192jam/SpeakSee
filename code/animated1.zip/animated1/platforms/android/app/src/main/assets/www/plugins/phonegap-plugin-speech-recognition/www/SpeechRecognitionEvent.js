cordova.define("phonegap-plugin-speech-recognition.SpeechRecognitionEvent", function(require, exports, module) {
var SpeechRecognitionEvent = function() {
    this.resultIndex;
    this.results;
    this.interpretation;
    this.emma;
};

module.exports = SpeechRecognitionEvent;

});
